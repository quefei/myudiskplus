#!/bin/bash

# 手动拷贝到 shell 目录才会执行，执行之后会自动备份到 shell-bak 目录

